# we need a resource that can carry the different data ingestion methods
# we aim to support 3 different inputs: 
# do we need three different functions? 
# and an associated dictionary per tool?

# then the class will have a switch depending on the input.
# 

# i guess we need a common name for each table we are querying?
# have a key for each.

# lets experiment with somethings small.

{
    'rd_sql': f"""
			SELECT
				DISTINCT participant_id,
				normalised_specific_disease
			FROM
				rare_diseases_participant_disease
			WHERE 
				normalised_specific_disease IN ({term_join}) 
			"""
}